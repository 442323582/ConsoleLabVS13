#include "Calculator.h"

#include<iostream>

using namespace std;



Calculator::Calculator(int maxIterTime)
{
	this->maxIterTime = maxIterTime;
}

void Calculator::setControl(Control * ctrl){
	this->ctrl = ctrl;
}

void Calculator::setNetwork(Network * net){
	this->net = net;
}

void Calculator::setEvolution(Evolution * evo){
	this->evo = evo;
}

void Calculator::setDecision(Decision * dec){
	this->dec = dec;
}

void Calculator::communicate(Message message){
	if (message == predict){
		evo->evolute(*net,*ctrl);
	}
	else if (message == decide){
		dec->decide(*net, *ctrl);
	}
	else if (message == update){
		ctrl->update(*net, *dec);
	}
	else{

	}
}

void Calculator::calculate(){
	for (int i = 0; i < maxIterTime; i++){
		communicate(predict);
		communicate(decide);
		communicate(update);
	}
}

Calculator::~Calculator()
{
}
