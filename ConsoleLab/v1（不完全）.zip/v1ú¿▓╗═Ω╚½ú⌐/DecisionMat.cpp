#include "DecisionMat.h"


#include<iostream>

using namespace std;

DecisionMat::DecisionMat(int nTime, int nNode, double initValue, string name)
{
	mat = new MatrixXd(nTime, nNode);
	mat->setOnes(nTime, nNode);
	(*mat) = (*mat)*initValue;
	this->name = name;
}

string DecisionMat::getName(){
	return name;
}

double DecisionMat::getValue(int iTime, int iNode){
	return (*mat)(iTime, iNode);
}

void DecisionMat::setValue(int iTime, int iNode, double val){
	(*mat)(iTime, iNode) = val;
}

int DecisionMat::getnTime(){
	return mat->rows();
}

int DecisionMat::getnNode(){
	return mat->cols();
}

DecisionMat::~DecisionMat()
{
}
