#include "Evolution.h"


Evolution::Evolution()
{
}

void Evolution::setNumDiffMethod(NumDiffMethod *method){
	this->method = method;
}

EvoRule Evolution::getRule(int iRule){
	return ruleList[iRule];
}

void Evolution::addRule(EvoRule evoRule){
	ruleList.push_back(evoRule);
}

void Evolution::evolute(Network & network, const Control & control){
	int nState = network.getnState();
	if (nState <= 0)
		return;
	NodeState *state = network.getNodeState(1);
	int nTime = state->getnTime();
	int nNode = state->getnNode();
	double base = 0;
	double val = 0;
	double diffVal = 0;
	for (int iTime = 0; iTime < nTime - 1; iTime++){
		for (int istate = 0; istate < nState; istate++){
			state = network.getNodeState(istate);
			for (int iNode = 0; iNode < nNode; iNode++){
				base = state->getValue(iTime, iNode);
				diffVal = ruleList[istate](network, control, iTime, iNode);
				state->setValue(iTime+1, iNode, diffVal);
			}
		}	
	}
}

int Evolution::getnRule(){
	int nRule = ruleList.size();
	return nRule;
}

Evolution::~Evolution()
{
}
