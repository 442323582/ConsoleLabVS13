#pragma once
#include"Topology.h"
#include"NodeState.h"

#include<vector>

using namespace std;

class Network
{
public:
	Network(string fileName, string name);
	~Network();
	void setTopo(string fileName);
	void addNodeState(int nTime, int nNode, string name, double initValue);
	Topology* getTopo();
	NodeState * getNodeState(int iState);
	int getnState();
private:
	Topology *topo;
	string name;
	vector<NodeState> nodeStateList;
};

