#pragma once
#include <Eigen\Dense>
#include<string>

using namespace std;
using namespace Eigen;
class DecisionMat
{
public:
	DecisionMat(int nTime, int nNode, double initValue, string name);
	~DecisionMat();
	double getValue(int iTime, int nNode);
	int getnTime();
	int getnNode();
	string getName();
	void setValue(int iTime, int nNode, double val);
private:
	MatrixXd * mat;
	string name;
};

