#pragma once
#include <Eigen\Dense>
#include<string>

using namespace std;
using namespace Eigen;

class NodeState
{
public:
	NodeState(int nTime,int nNode,double initValue, string name);
	~NodeState();
	double getValue(int iTime,int nNode);
	int getnTime();
	int getnNode();
	void setValue(int iTime, int nNode,double val);
	string getName();
private:
	MatrixXd * mat;
	string name;
};

