

#pragma once

#include <Eigen\Dense>
#include"Network.h"

using namespace Eigen;

class Decision;

typedef double(*CtrlRule)(const Network&, const Decision&, int);

class Control
{
public:
	Control(int nTime, int nCtrl, double initValue);
	~Control();
	void update(const Network & network, const Decision & dec);
	void setMax(double val);
	void setMin(double val);
	double getValue(int iTime, int iCtrl);
	void setValue(int iTime, int iCtrl, double val);
	void addRule(CtrlRule rule);
	CtrlRule getRule(int iRule);
	int getnRule();
	int getnTime();
	int getnCtrl();
private:
	double max;
	double min;
	MatrixXd * mat;
	string name;
	vector<CtrlRule> ruleList;
};

