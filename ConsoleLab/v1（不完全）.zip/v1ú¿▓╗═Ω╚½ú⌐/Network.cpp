#include "Network.h"
#include<iostream>

using namespace std;

void Network::addNodeState(int nTime, int nNode, string name, double initValue){
	nodeStateList.push_back(NodeState(nTime, nNode, initValue, name));
}

int Network::getnState(){
	int nState = nodeStateList.size();
	return nState;
}

Topology* Network::getTopo(){
	return topo;
}

NodeState * Network::getNodeState(int iState){
	return &nodeStateList[iState];
}


Network::Network(string fileName, string name)
{
	this->name = name;
	this->topo = new Topology;
	topo->readDat(fileName);

}

void Network::setTopo(string fileName){
	delete(this->topo);
	this->topo = new Topology;
	topo->readDat(fileName);
}

Network::~Network()
{
}
