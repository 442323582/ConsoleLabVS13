#include "Control.h"

#include<iostream>

using namespace std;

Control::Control(int nTime, int nCtrl, double initValue)
{
	mat = new MatrixXd(nTime, nCtrl);
	mat->setOnes(nTime, nCtrl);
	(*mat) = (*mat)*initValue;
	name = "���ƾ���";
}

int Control::getnTime(){
	return mat->rows();
}

int Control::getnCtrl(){
	return mat->cols();
}

void Control::update(const Network & network, const Decision & dec){
	int nTime = mat->rows();
	int nCtrl = mat->cols();
	double val = 0;
	CtrlRule currRule;
	for (int iTime = 1; iTime < nTime; iTime++){
		for (int iRule = 0; iRule < getnRule(); iRule++){
			currRule = getRule(iRule);
			val = currRule(network, dec, iTime);
			setValue(iTime, iRule,val);
		}
	}
}


void Control::addRule(CtrlRule rule){
	ruleList.push_back(rule);
}

CtrlRule Control::getRule(int iRule){
	return ruleList[iRule];
}


double Control::getValue(int iTime, int iCtrl){
	return (*mat)(iTime, iCtrl);
}

void Control::setValue(int iTime, int iCtrl, double val){
	if (val > max){
		val = max;
	}
	else if (val < min){
		val = min;
	}
	(*mat)(iTime, iCtrl) = val;
}

void Control::setMax(double val){
	max = val;
}

void Control::setMin(double val){
	min = val;
}


int Control::getnRule(){
return ruleList.size();
}

Control::~Control()
{
}
