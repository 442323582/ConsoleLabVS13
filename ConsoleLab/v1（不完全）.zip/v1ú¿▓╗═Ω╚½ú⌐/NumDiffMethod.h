#pragma once

class NumDiffMethod
{
public:
	NumDiffMethod(double stepLength);
	~NumDiffMethod();
	double action(double base, bool direction, double diffVal);
private:
	double stepLength;
};

