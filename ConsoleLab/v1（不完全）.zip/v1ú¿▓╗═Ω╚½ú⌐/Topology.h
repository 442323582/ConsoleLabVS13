#pragma once

#include <Eigen\Dense>

#include<string>

using namespace std;

using namespace Eigen;

class Topology
{
public:
	Topology();
	~Topology();
	void readDat(string fileName);
	int getnNode();
	int getDegree(int iNode);
	int getValue(int i, int j);
private:
	MatrixXi * mat;
	int * degreeArray;
	int nNode;
};

