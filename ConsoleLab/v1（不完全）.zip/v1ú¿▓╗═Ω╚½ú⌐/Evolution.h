#pragma once

#include<vector>
#include"Control.h"
#include"Network.h"
#include"NumDiffMethod.h"

using namespace std;

typedef double(*EvoRule)(const Network&, const Control&, int, int);

class Evolution
{
public:
	Evolution();
	~Evolution();
	EvoRule getRule(int iRule);
	void evolute(Network & network, const Control & control);
	void addRule(EvoRule);
	int getnRule();
	void setNumDiffMethod(NumDiffMethod * method);
private:
	vector<EvoRule> ruleList;
	NumDiffMethod * method;
};

