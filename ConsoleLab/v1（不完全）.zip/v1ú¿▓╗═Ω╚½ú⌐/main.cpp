
#include"Topology.h"
#include"NodeState.h"
#include"Network.h"
#include"Evolution.h"
#include"Control.h"
#include"NumDiffMethod.h"
#include"Decision.h"
#include"Calculator.h"
#include"Output.h"

#include<iostream>

using namespace std;

double testfunc(const Network&, const Control&, int iTime, int iNode);
double testfunc_1(const Network&, const Decision&, int iTime);

int main(){
	Network network("network.dat", "SmallWorld");
	network.addNodeState(4, 4, "I", 0.1);
	network.addNodeState(4, 4, "P", 0.1);
	Evolution evo;
	evo.addRule(testfunc);
	evo.addRule(testfunc);
	Control control(4,1,0.4);
	control.setMax(0.8);
	control.setMin(0.2);
	control.addRule(testfunc_1);
	NumDiffMethod method(0.01);
	evo.setNumDiffMethod(&method);
	Decision dec;
	dec.setNumDiffMethod(&method);
	dec.addRule(testfunc);
	dec.addRule(testfunc);
	dec.addMat(4, 4, "Lambda", 0);
	dec.addMat(4, 4, "Mu", 0);
	Calculator cal(1);
	cal.setControl(&control);
	cal.setDecision(&dec);
	cal.setEvolution(&evo);
	cal.setNetwork(&network);
	cal.calculate();
	Output out;
	out.print(*network.getTopo());
	out.print(*network.getNodeState(0));
	out.print(*network.getNodeState(1));
	out.print(control);
	out.print(*dec.getMat(0));
	out.print(*dec.getMat(1));
	char c;
	cin >> c;

	return 0;
}


double testfunc(const Network&, const Control&, int iTime, int iNode){
	return 3.5;
}

double testfunc_1(const Network&, const Decision&, int iTime){
	return 2.5;
}
