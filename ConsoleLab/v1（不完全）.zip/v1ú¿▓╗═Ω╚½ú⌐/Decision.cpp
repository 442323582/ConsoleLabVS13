#include "Decision.h"

Decision::Decision()
{
	
}

void Decision::addMat(int nTime, int nNode, string name, double initValue){
	matList.push_back(DecisionMat(nTime, nNode, initValue, name));
}

int Decision::getnMat(){
	int nMat = matList.size();
	return nMat;
}

DecisionMat * Decision::getMat(int iMat){
	return &matList[iMat];
}

void Decision::setNumDiffMethod(NumDiffMethod *method){
	this->method = method;
}

DecisionRule Decision::getRule(int iRule){
	return ruleList[iRule];
}

void Decision::addRule(DecisionRule rule){
	ruleList.push_back(rule);
}

void Decision::decide(const Network & network, const Control & control){
	int nMat = getnMat();
	if (nMat <= 0)
		return;
	DecisionMat *currMat = getMat(1);
	int nTime = currMat->getnTime();
	int nNode = currMat->getnNode();
	double base = 0;
	double val = 0;
	double diffVal = 0;
	for (int iTime = nTime - 1; iTime > 0; iTime--){
		for (int iMat = 0; iMat < nMat; iMat++){
			currMat = getMat(iMat);
			for (int iNode = 0; iNode < nNode; iNode++){
				base = currMat->getValue(iTime, iNode);
				diffVal = ruleList[iMat](network, control, iTime, iNode);
				currMat->setValue(iTime - 1, iNode, diffVal);
			}
		}
	}
}

int Decision::getnRule(){
	int nRule = ruleList.size();
	return nRule;
}

Decision::~Decision()
{
}
