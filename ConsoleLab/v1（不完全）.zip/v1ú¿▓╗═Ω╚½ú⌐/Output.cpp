#include "Output.h"

#include<iostream>

using namespace std;

Output::Output()
{
}

void Output::print(Topology & topo){
	cout << "---���˽ṹ---" << endl;
	for (int i = 0; i < topo.getnNode(); i++){
		for (int j = 0; j < topo.getnNode(); j++){
			cout << topo.getValue(i, j) << " ";
		}
		cout << endl;
	}
	cout << endl;
}

void Output::print(NodeState & state){
	cout << "---" << state.getName() << "---" << endl;
	for (int i = 0; i < state.getnTime(); i++){
		for (int j = 0; j < state.getnNode(); j++){
			cout << state.getValue(i, j) << " ";
		}
		cout << endl;
	}
	cout << endl;
}

void Output::print(Control & ctrl){
	cout << "---" << "���ƾ���" << "---" << endl;
	for (int i = 0; i < ctrl.getnTime(); i++){
		for (int j = 0; j < ctrl.getnCtrl(); j++){
			cout << ctrl.getValue(i, j) << " ";
		}
		cout << endl;
	}
	cout << endl;
}

void Output::print(DecisionMat & decMat){
	cout << "---" << decMat.getName() << "---" << endl;
	for (int i = 0; i < decMat.getnTime(); i++){
		for (int j = 0; j < decMat.getnNode(); j++){
			cout << decMat.getValue(i, j) << " ";
		}
		cout << endl;
	}
	cout << endl;
}


Output::~Output()
{
}
