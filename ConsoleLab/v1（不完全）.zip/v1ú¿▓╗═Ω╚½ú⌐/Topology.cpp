#include "Topology.h"

#include<iostream>
#include<fstream>
#include<sstream> 

using namespace std;

Topology::Topology()
{
}

int Topology::getValue(int i,int j){
	int val;
	val = (*mat)(i, j);
	return val;
}

void Topology::readDat(string fileName){
	//��ȡ�ڽӾ���
	ifstream file;
	file.open(fileName, ios::_Nocreate | ios::in);
	if (!file){
		cout << "��ȡ�ڽӾ���ʧ�ܡ�";
		return;
	}
	int nLine = 0;
	char strbuff[256];
	while (file.getline(strbuff, 256)){ // ��ȡ�ڵ���
		nLine++;
	}
	nNode = nLine;
	file.clear();
	file.seekg(0,ios::beg);
	mat = new MatrixXi(nLine, nLine);
	for (int i = 0; i < nLine; i++){
		for (int j = 0; j < nLine; j++){
			file >> (*mat)(i,j); 
		}
	}
	file.close();

	//��ڵ������
	degreeArray = new int[nLine];
	for (int i = 0; i < nLine; i++){
		degreeArray[i] = mat->row(i).sum();
	}
	cout << "��ȡ�ڽӾ���ɹ���\n" << endl;
}

int Topology::getnNode(){
	return nNode;
}

int Topology::getDegree(int iNode){ //�ڵ��1��ʼ
	return degreeArray[iNode-1];
}

Topology::~Topology()
{
}
