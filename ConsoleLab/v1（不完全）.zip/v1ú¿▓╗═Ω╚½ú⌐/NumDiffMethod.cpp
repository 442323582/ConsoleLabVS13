#include "NumDiffMethod.h"


NumDiffMethod::NumDiffMethod(double stepLength)
{
	this->stepLength = stepLength;
}

double NumDiffMethod::action(double base, bool direction, double diffVal){
	double val;
	if (direction){
		val = base + stepLength * diffVal;
	}
	else
	{
		val = base - stepLength * diffVal;
	}
	return val;
}

NumDiffMethod::~NumDiffMethod()
{
}
