#include "NodeState.h"

#include<iostream>

using namespace std;

NodeState::NodeState(int nTime, int nNode, double initValue, string name)
{
	mat = new MatrixXd(nTime, nNode);
	mat->setOnes(nTime, nNode);
	(*mat) = (*mat)*initValue;
	this->name = name;
}

double NodeState::getValue(int iTime,int iNode){
	return (*mat)(iTime,iNode);
}

void NodeState::setValue(int iTime, int iNode, double val){
	if (val > 1)
		val = 1;
	else if (val < 0)
		val = 0;
	(*mat)(iTime, iNode) = val;
}

int NodeState::getnTime(){
	return mat->rows();
}

int NodeState::getnNode(){
	return mat->cols();
}

string NodeState::getName(){
	return name;
}

NodeState::~NodeState()
{
}


