#pragma once

#include"Network.h"
#include"Control.h"
#include"Decision.h"
#include"Evolution.h"

enum Message
{
	predict,
	decide,
	update
};

class Calculator
{
public:
	Calculator(int maxIterTime);
	~Calculator();
	void calculate();
	void setControl(Control * ctrl);
	void setEvolution(Evolution * evo);
	void setDecision(Decision * dec);
	void setNetwork(Network * net);
	void communicate(Message message);
private:
	int maxIterTime;
	Control *ctrl;
	Evolution *evo;
	Decision *dec;
	Network *net;
};

