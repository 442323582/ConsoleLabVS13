#pragma once

#include"Topology.h"
#include"NodeState.h"
#include"Control.h"
#include"DecisionMat.h"

class Output
{
public:
	Output();
	~Output();
	void print(Topology & topo);
	void print(NodeState & state);
	void print(Control & ctrl);
	void print(DecisionMat & decMat);
};

