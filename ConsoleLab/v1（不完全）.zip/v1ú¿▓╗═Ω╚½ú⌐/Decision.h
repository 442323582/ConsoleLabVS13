

#pragma once

#include <Eigen\Dense>
#include"Network.h"
#include"Control.h"
#include"NumDiffMethod.h"
#include"DecisionMat.h"

using namespace Eigen;

typedef double(*DecisionRule)(const Network&, const Control&, int, int);


class Decision
{
public:
	Decision();
	~Decision();
	DecisionRule getRule(int iRule);
	void decide(const Network & network, const Control & control);
	void addRule(DecisionRule);
	int getnRule();
	void setNumDiffMethod(NumDiffMethod * method);
	void addMat(int nTime, int nNode, string name, double initValue);
	DecisionMat * getMat(int iMat);
	int getnMat();
private:
	vector<DecisionMat> matList;
	vector<DecisionRule> ruleList;
	NumDiffMethod * method;
};



